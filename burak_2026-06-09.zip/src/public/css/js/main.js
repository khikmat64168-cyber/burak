console.log('Frontend Javascript starts');
